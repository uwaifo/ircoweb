/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getUser = /* GraphQL */ `
  query GetUser($id: ID!) {
    getUser(id: $id) {
      id
      email
      firstName
      lastName
      phoneNumber
      phoneType
      surveyStatus
      address {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const listUsers = /* GraphQL */ `
  query ListUsers(
    $filter: ModelUserFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listUsers(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        email
        firstName
        lastName
        phoneNumber
        phoneType
        surveyStatus
        address {
          id
          addressLineOne
          addressLineTwo
          city
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
export const getUserAddress = /* GraphQL */ `
  query GetUserAddress($id: ID!) {
    getUserAddress(id: $id) {
      id
      addressLineOne
      addressLineTwo
      city
      state {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const listUserAddresss = /* GraphQL */ `
  query ListUserAddresss(
    $filter: ModelUserAddressFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listUserAddresss(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
export const getSurveyQuestion = /* GraphQL */ `
  query GetSurveyQuestion($id: ID!) {
    getSurveyQuestion(id: $id) {
      id
      questionType
      questionText
      responseOption {
        items {
          id
          text
          is_correct
          createdAt
          updatedAt
        }
        nextToken
      }
      createdAt
      updatedAt
    }
  }
`;
export const listSurveyQuestions = /* GraphQL */ `
  query ListSurveyQuestions(
    $filter: ModelSurveyQuestionFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listSurveyQuestions(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
export const getResponseOption = /* GraphQL */ `
  query GetResponseOption($id: ID!) {
    getResponseOption(id: $id) {
      id
      question {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      text
      is_correct
      createdAt
      updatedAt
    }
  }
`;
export const listResponseOptions = /* GraphQL */ `
  query ListResponseOptions(
    $filter: ModelResponseOptionFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listResponseOptions(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        question {
          id
          questionType
          questionText
          createdAt
          updatedAt
        }
        text
        is_correct
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
export const getSurveySession = /* GraphQL */ `
  query GetSurveySession($id: ID!) {
    getSurveySession(id: $id) {
      id
      userId
      sessionQuestions {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const listSurveySessions = /* GraphQL */ `
  query ListSurveySessions(
    $filter: ModelSurveySessionFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listSurveySessions(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        userId
        sessionQuestions {
          id
          questionType
          questionText
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
export const getStates = /* GraphQL */ `
  query GetStates($id: ID!) {
    getStates(id: $id) {
      id
      name
      abbreviation
      createdAt
      updatedAt
    }
  }
`;
export const listStatess = /* GraphQL */ `
  query ListStatess(
    $filter: ModelStatesFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listStatess(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
