/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateUser = /* GraphQL */ `
  subscription OnCreateUser {
    onCreateUser {
      id
      email
      firstName
      lastName
      phoneNumber
      phoneType
      surveyStatus
      address {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateUser = /* GraphQL */ `
  subscription OnUpdateUser {
    onUpdateUser {
      id
      email
      firstName
      lastName
      phoneNumber
      phoneType
      surveyStatus
      address {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteUser = /* GraphQL */ `
  subscription OnDeleteUser {
    onDeleteUser {
      id
      email
      firstName
      lastName
      phoneNumber
      phoneType
      surveyStatus
      address {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onCreateUserAddress = /* GraphQL */ `
  subscription OnCreateUserAddress {
    onCreateUserAddress {
      id
      addressLineOne
      addressLineTwo
      city
      state {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateUserAddress = /* GraphQL */ `
  subscription OnUpdateUserAddress {
    onUpdateUserAddress {
      id
      addressLineOne
      addressLineTwo
      city
      state {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteUserAddress = /* GraphQL */ `
  subscription OnDeleteUserAddress {
    onDeleteUserAddress {
      id
      addressLineOne
      addressLineTwo
      city
      state {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onCreateSurveyQuestion = /* GraphQL */ `
  subscription OnCreateSurveyQuestion {
    onCreateSurveyQuestion {
      id
      questionType
      questionText
      responseOption {
        items {
          id
          text
          is_correct
          createdAt
          updatedAt
        }
        nextToken
      }
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateSurveyQuestion = /* GraphQL */ `
  subscription OnUpdateSurveyQuestion {
    onUpdateSurveyQuestion {
      id
      questionType
      questionText
      responseOption {
        items {
          id
          text
          is_correct
          createdAt
          updatedAt
        }
        nextToken
      }
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteSurveyQuestion = /* GraphQL */ `
  subscription OnDeleteSurveyQuestion {
    onDeleteSurveyQuestion {
      id
      questionType
      questionText
      responseOption {
        items {
          id
          text
          is_correct
          createdAt
          updatedAt
        }
        nextToken
      }
      createdAt
      updatedAt
    }
  }
`;
export const onCreateResponseOption = /* GraphQL */ `
  subscription OnCreateResponseOption {
    onCreateResponseOption {
      id
      question {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      text
      is_correct
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateResponseOption = /* GraphQL */ `
  subscription OnUpdateResponseOption {
    onUpdateResponseOption {
      id
      question {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      text
      is_correct
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteResponseOption = /* GraphQL */ `
  subscription OnDeleteResponseOption {
    onDeleteResponseOption {
      id
      question {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      text
      is_correct
      createdAt
      updatedAt
    }
  }
`;
export const onCreateSurveySession = /* GraphQL */ `
  subscription OnCreateSurveySession {
    onCreateSurveySession {
      id
      userId
      sessionQuestions {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateSurveySession = /* GraphQL */ `
  subscription OnUpdateSurveySession {
    onUpdateSurveySession {
      id
      userId
      sessionQuestions {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteSurveySession = /* GraphQL */ `
  subscription OnDeleteSurveySession {
    onDeleteSurveySession {
      id
      userId
      sessionQuestions {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const onCreateStates = /* GraphQL */ `
  subscription OnCreateStates {
    onCreateStates {
      id
      name
      abbreviation
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateStates = /* GraphQL */ `
  subscription OnUpdateStates {
    onUpdateStates {
      id
      name
      abbreviation
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteStates = /* GraphQL */ `
  subscription OnDeleteStates {
    onDeleteStates {
      id
      name
      abbreviation
      createdAt
      updatedAt
    }
  }
`;
