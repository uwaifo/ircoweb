/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createUser = /* GraphQL */ `
  mutation CreateUser(
    $input: CreateUserInput!
    $condition: ModelUserConditionInput
  ) {
    createUser(input: $input, condition: $condition) {
      id
      email
      firstName
      lastName
      phoneNumber
      phoneType
      surveyStatus
      address {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const updateUser = /* GraphQL */ `
  mutation UpdateUser(
    $input: UpdateUserInput!
    $condition: ModelUserConditionInput
  ) {
    updateUser(input: $input, condition: $condition) {
      id
      email
      firstName
      lastName
      phoneNumber
      phoneType
      surveyStatus
      address {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const deleteUser = /* GraphQL */ `
  mutation DeleteUser(
    $input: DeleteUserInput!
    $condition: ModelUserConditionInput
  ) {
    deleteUser(input: $input, condition: $condition) {
      id
      email
      firstName
      lastName
      phoneNumber
      phoneType
      surveyStatus
      address {
        id
        addressLineOne
        addressLineTwo
        city
        state {
          id
          name
          abbreviation
          createdAt
          updatedAt
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const createUserAddress = /* GraphQL */ `
  mutation CreateUserAddress(
    $input: CreateUserAddressInput!
    $condition: ModelUserAddressConditionInput
  ) {
    createUserAddress(input: $input, condition: $condition) {
      id
      addressLineOne
      addressLineTwo
      city
      state {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const updateUserAddress = /* GraphQL */ `
  mutation UpdateUserAddress(
    $input: UpdateUserAddressInput!
    $condition: ModelUserAddressConditionInput
  ) {
    updateUserAddress(input: $input, condition: $condition) {
      id
      addressLineOne
      addressLineTwo
      city
      state {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const deleteUserAddress = /* GraphQL */ `
  mutation DeleteUserAddress(
    $input: DeleteUserAddressInput!
    $condition: ModelUserAddressConditionInput
  ) {
    deleteUserAddress(input: $input, condition: $condition) {
      id
      addressLineOne
      addressLineTwo
      city
      state {
        id
        name
        abbreviation
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const createSurveyQuestion = /* GraphQL */ `
  mutation CreateSurveyQuestion(
    $input: CreateSurveyQuestionInput!
    $condition: ModelSurveyQuestionConditionInput
  ) {
    createSurveyQuestion(input: $input, condition: $condition) {
      id
      questionType
      questionText
      responseOption {
        items {
          id
          text
          is_correct
          createdAt
          updatedAt
        }
        nextToken
      }
      createdAt
      updatedAt
    }
  }
`;
export const updateSurveyQuestion = /* GraphQL */ `
  mutation UpdateSurveyQuestion(
    $input: UpdateSurveyQuestionInput!
    $condition: ModelSurveyQuestionConditionInput
  ) {
    updateSurveyQuestion(input: $input, condition: $condition) {
      id
      questionType
      questionText
      responseOption {
        items {
          id
          text
          is_correct
          createdAt
          updatedAt
        }
        nextToken
      }
      createdAt
      updatedAt
    }
  }
`;
export const deleteSurveyQuestion = /* GraphQL */ `
  mutation DeleteSurveyQuestion(
    $input: DeleteSurveyQuestionInput!
    $condition: ModelSurveyQuestionConditionInput
  ) {
    deleteSurveyQuestion(input: $input, condition: $condition) {
      id
      questionType
      questionText
      responseOption {
        items {
          id
          text
          is_correct
          createdAt
          updatedAt
        }
        nextToken
      }
      createdAt
      updatedAt
    }
  }
`;
export const createResponseOption = /* GraphQL */ `
  mutation CreateResponseOption(
    $input: CreateResponseOptionInput!
    $condition: ModelResponseOptionConditionInput
  ) {
    createResponseOption(input: $input, condition: $condition) {
      id
      question {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      text
      is_correct
      createdAt
      updatedAt
    }
  }
`;
export const updateResponseOption = /* GraphQL */ `
  mutation UpdateResponseOption(
    $input: UpdateResponseOptionInput!
    $condition: ModelResponseOptionConditionInput
  ) {
    updateResponseOption(input: $input, condition: $condition) {
      id
      question {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      text
      is_correct
      createdAt
      updatedAt
    }
  }
`;
export const deleteResponseOption = /* GraphQL */ `
  mutation DeleteResponseOption(
    $input: DeleteResponseOptionInput!
    $condition: ModelResponseOptionConditionInput
  ) {
    deleteResponseOption(input: $input, condition: $condition) {
      id
      question {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      text
      is_correct
      createdAt
      updatedAt
    }
  }
`;
export const createSurveySession = /* GraphQL */ `
  mutation CreateSurveySession(
    $input: CreateSurveySessionInput!
    $condition: ModelSurveySessionConditionInput
  ) {
    createSurveySession(input: $input, condition: $condition) {
      id
      userId
      sessionQuestions {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const updateSurveySession = /* GraphQL */ `
  mutation UpdateSurveySession(
    $input: UpdateSurveySessionInput!
    $condition: ModelSurveySessionConditionInput
  ) {
    updateSurveySession(input: $input, condition: $condition) {
      id
      userId
      sessionQuestions {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const deleteSurveySession = /* GraphQL */ `
  mutation DeleteSurveySession(
    $input: DeleteSurveySessionInput!
    $condition: ModelSurveySessionConditionInput
  ) {
    deleteSurveySession(input: $input, condition: $condition) {
      id
      userId
      sessionQuestions {
        id
        questionType
        questionText
        responseOption {
          nextToken
        }
        createdAt
        updatedAt
      }
      createdAt
      updatedAt
    }
  }
`;
export const createStates = /* GraphQL */ `
  mutation CreateStates(
    $input: CreateStatesInput!
    $condition: ModelStatesConditionInput
  ) {
    createStates(input: $input, condition: $condition) {
      id
      name
      abbreviation
      createdAt
      updatedAt
    }
  }
`;
export const updateStates = /* GraphQL */ `
  mutation UpdateStates(
    $input: UpdateStatesInput!
    $condition: ModelStatesConditionInput
  ) {
    updateStates(input: $input, condition: $condition) {
      id
      name
      abbreviation
      createdAt
      updatedAt
    }
  }
`;
export const deleteStates = /* GraphQL */ `
  mutation DeleteStates(
    $input: DeleteStatesInput!
    $condition: ModelStatesConditionInput
  ) {
    deleteStates(input: $input, condition: $condition) {
      id
      name
      abbreviation
      createdAt
      updatedAt
    }
  }
`;
